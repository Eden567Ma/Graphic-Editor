module pobj.pinboard {
	exports pobj.pinboard.editor;
	exports pobj.pinboard.test;
	requires javafx.base;
	requires javafx.graphics;
	requires transitive javafx.controls;
	requires junit;
}